drop table dwh.dim_battalion;
drop table dwh.dim_district;
drop table dwh.fact_fire_incidents;

drop table stg.battalion;
drop table stg.district;
drop table stg.fire_incidents;

drop table prev.battalion;
drop table prev.district;
drop table prev.fire_incidents;